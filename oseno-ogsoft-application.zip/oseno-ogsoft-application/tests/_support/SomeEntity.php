<?php

namespace Tests\Support;

use CodeIgniter\Entity;

class SomeEntity extends Entity
{
	protected $attributes = [
		'foo' => null,
		'bar' => null,
	];

}
