Please create MySQL database called "userdetails", table called "users" with the following columns and data types and open myphpadmin to view database.

Columns and data types are as follows:

id (Primary	Key) int(10),	fname	varchar(50),	mname	varchar(25),	lname	varchar(50),	email	varchar(50),	username	varchar(25),	password	varchar(255),	created_at	datetime,	updated_at	datetime,	dob	date,	address	varchar(255),	country	varchar(25),	mstatus	varchar(18),	gender	varchar(50),	nok	varchar(255),phonenum	varchar(20)

Next, go into your xampp httpd-contf file and change your root directory to the file name(in this case it is oseno-ogsoft-application, if you change it, please use that accordingly). The root directory and directory must match. Also, changed filename would need to be done in the javascript code on line 12.

Next, go into your browser and simply type in localhost and you are met with my submission. Please be connected to the internet so as to load the complete design eg font awesome icons

Codeigniter 4 is used for my backend and MYSQL for database with Angularjs in the front end as requested. However, I did not use angularjs in my dashboard code at all, as this was the best time effective solution for me.

I hope this is satisfactory, thank you.